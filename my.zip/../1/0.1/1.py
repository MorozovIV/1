import sys
print(sys.copyright)