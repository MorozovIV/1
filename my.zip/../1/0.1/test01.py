import sys
a, b = sys.stdin.read().split()
print(int(a) + int(b))