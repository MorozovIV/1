count = 8
message = 'У вас' +str(count) 'новых сообщений'  # допишите ваш код здесь
print(str(message))