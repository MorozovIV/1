# import my_modules as mod
import my_modules
# mod.hello()
# my_modules.hello()
my_modules.hello()
my_modules.vremya()