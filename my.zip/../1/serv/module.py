if __name__ == "__main__":
    print("Hello")
try:
    def hi():                   #import module
        print("Привет")         #module.hi
except:
     pass