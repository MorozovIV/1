import module
module.hi()