import datetime
def vremya():
    vremya = datetime.datetime.now()
    print(vremya)